# Number Psychology AI Analyzer

## आवश्यकताएँ
- Node.js 20 या नया
- OpenAI API key और API billing/credits
- इंटरनेट कनेक्शन

## चलाने का तरीका
1. ZIP extract करें।
2. इस फ़ोल्डर में terminal खोलें और `npm install` चलाएँ।
3. `.env.example` की कॉपी बनाकर `.env` नाम दें।
4. `.env` में `OPENAI_API_KEY=आपकी_API_key` भरें। API key कभी `public/index.html` में न डालें और किसी से साझा न करें।
5. `npm start` चलाएँ।
6. उसी डिवाइस पर `http://localhost:3000` खोलें।

फोन पर उपयोग: backend किसी कंप्यूटर या HTTPS hosting पर चलाएँ; फिर उस server का HTTPS URL फोन के Chrome में खोलें। केवल फोन में HTML खोलने से Node backend/API नहीं चलेगा।

## Hosting
Node.js support वाला hosting provider चुनें। Environment variables में `OPENAI_API_KEY` और वैकल्पिक `OPENAI_MODEL` सेट करें। `npm start` को start command रखें। HTTPS अनिवार्य रखें। API key hosting के secret/environment settings में ही रहे।

## सुरक्षा
- API key server-side `.env` में रहती है।
- API endpoint पर basic rate limit है।
- `.env` GitHub या ZIP में upload न करें।
- सार्वजनिक deployment से पहले authentication, stricter per-user quotas, logging policy और abuse protection जोड़ें।
- AI output को betting/financial advice न मानें; random outcomes का भरोसेमंद अनुमान नहीं लगाया जा सकता।

## Mapping
`server.js` में Big/Small, Red/Green और Violet mappings हैं। यदि source chart का नियम अलग हो तो उसे verify करके बदलें।
