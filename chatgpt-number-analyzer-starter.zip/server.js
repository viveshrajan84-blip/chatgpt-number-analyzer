import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 3000);
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: "draft-8", legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

const rules = {
  big: [5,6,7,8,9], small: [0,1,2,3,4],
  red: [0,2,4,6,8], green: [1,3,5,7,9],
  violet: [0,5]
};
function traits(n) {
  return { number:n, size:rules.big.includes(n)?"Big":"Small",
    color:rules.violet.includes(n)?"Violet":(rules.red.includes(n)?"Red":"Green") };
}
app.get("/api/health", (_req,res) => res.json({ ok:true, aiConfigured:Boolean(client) }));

app.post("/api/analyze", async (req,res) => {
  try {
    if (!client) return res.status(503).json({ error:"Server पर OPENAI_API_KEY सेट नहीं है। .env फाइल देखें।" });
    const raw = req.body?.results;
    if (!Array.isArray(raw) || raw.length < 3 || raw.length > 500 ||
        raw.some(n => !Number.isInteger(n) || n < 0 || n > 9)) {
      return res.status(400).json({ error:"कम-से-कम 3 और अधिकतम 500 परिणाम दें; हर परिणाम 0–9 का पूर्णांक हो।" });
    }
    const recent = raw.slice(-10);
    const facts = recent.map((n,i)=>({position:i+1,...traits(n)}));
    const prompt = `आप एक सावधान sequence-analysis assistant हैं। उपयोगकर्ता के परिणामों को वर्णनात्मक रूप से पढ़ें, भविष्य निश्चित बताने या betting advice देने का दावा न करें। यह गेम/ड्रॉ यादृच्छिक हो सकता है; पिछले परिणाम अगले परिणाम की विश्वसनीय संभावना नहीं बताते। किसी भी प्रतिशत/विश्वास स्कोर को वास्तविक statistical probability न कहें। 
Mapping: Big=5,6,7,8,9; Small=0,1,2,3,4; Red=0,2,4,6,8; Green=1,3,5,7,9; Violet marker=0,5.
आखिरी 3 और आखिरी 10 तक के क्रम को देखें। Repeat, alternation, size/color shifts, step movement, uncertainty को अलग-अलग बताएं। जब संकेत अस्पष्ट/परस्पर-विरोधी हों तो SKIP कहें। दो वैकल्पिक नंबर केवल illustrative candidates के रूप में दें, न कि safe bet। 
डेटा: ${JSON.stringify(facts)}
उत्तर हिंदी में, संक्षिप्त, इन headings के साथ: हालिया गुण, पैटर्न, Buying/Selling pressure (केवल रूपक), स्थिति (Clear/Sideways/Unclear/Skip), दो illustrative candidates और कारण, सीमाएँ।`;
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.4-mini",
      input: prompt,
      max_output_tokens: 700
    });
    res.json({ analysis: response.output_text || "AI से कोई टेक्स्ट उत्तर नहीं मिला।", recent:facts });
  } catch (err) {
    console.error("analysis_error", err?.message || err);
    res.status(500).json({ error:"AI विश्लेषण पूरा नहीं हो पाया। सर्वर लॉग देखें और पुनः प्रयास करें।" });
  }
});

app.listen(port, () => console.log(`Number Analyzer running: http://localhost:${port}`));
